#include "ESP8266_FIRE_BASE.h"

LiquidCrystal_I2C lcd(LCD_ADDRESS, LCD_SIZE / 100, LCD_SIZE % 100);

void Set_Up_Wifi(){


	lcd.clear();
	pinMode(D0, INPUT);
	WiFi.begin(USER_NAME, PASS_WORD);
	lcd.setCursor(0, 0);
	lcd.print("CONNECT TO WIFI...");
	unsigned long time = 0;
	while(WiFi.status() != WL_CONNECTED){

		delay(1);
		time++;
		if(time > 60000){
			
			lcd.setCursor(0, 0);
			lcd.print("Connect fail");
			lcd.setCursor(0, 1);
			lcd.print("Please check the router");
			while(1);
		}
	}
	lcd.setCursor(0, 1);
	lcd.print("Connect Success !");
	delay(2000);
}

void Lcd_Init(){

	Wire.begin();
	lcd.begin();
	lcd.backlight();
}

void Display_And_Control(uint8_t Signal){

	if(Signal == 1){									// 1 - Bật relay máy bơm, tín hiệu HIGH đi vào RELAY

		digitalWrite(D0, HIGH);
		lcd.setCursor(0, 0); lcd.print("Status:");
		lcd.setCursor(8, 0); lcd.print("ON ");
	}
	if(Signal == 0){									// 2 - Tắt relay máy bơm, tín hiệu LOW đi vào RELAY

		digitalWrite(D0, LOW);
		lcd.setCursor(0, 0); lcd.print("Status:");
		lcd.setCursor(8, 0); lcd.print("OFF");
	}
}

void Connect_To_Firebase(){

	lcd.setCursor(0, 0);
	lcd.print("Connect Firebase");
	Firebase.begin(FIRE_BASE_HOST, FIRE_BASE_AUTH);
	delay(500);
	lcd.setCursor(0, 1);
	lcd.print("Connect Success");
	delay(1000);
	lcd.clear();
}
void Get_Data_Fire_Base(){

	String path = "/";
	FirebaseObject object = Firebase.get(path);
	uint8_t signal = object.getInt("Signal");
	Display_And_Control(signal);
}

void Push_Data_Fire_Base(uint8_t hours, uint8_t minutes, uint8_t seconds, float Water_Flow){ // Gửi dữ liệu bao gồm mực nước và thời điểm (ở dạng HHMMSS)mực nước lên Firebase

	char time[50];
	sprintf(time, "%2d:%2d:%2d", hours, minutes, seconds);
	String String(time);
	Firebase.setFloat("Water_Flow", Water_Flow);
	Firebase.setString("Time_Update", time);
	lcd.setCursor(0, 1);
	lcd.print("Water_Flow: ");
	lcd.print(Water_Flow);
	lcd.setCursor(0, 2);
	lcd.print("Time: ");
	lcd.print(time);
}
