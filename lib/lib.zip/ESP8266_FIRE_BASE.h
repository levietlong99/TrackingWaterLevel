#ifndef ESP8266_FIRE_BASE_H_
#define ESP8266_FIRE_BASE_H_

#include <Arduino.h>
#include <ESP8266WiFi.h>		// Thư viện cần có để chọn board ESP8266, Link để prefrence board
#include <LiquidCrystal_I2C.h>  // Thư viện này đính kèm ở file bên ngoài
#include <ArduinoJson.h>		// Manage library "ArduinoJson" trong arduino, code này theo version 5x (Không phải 6x)
#include <FirebaseArduino.h>	// Include thư viện FirebaseArduino trong file đính kèm
#include <EEPROM.h>
#include <Wire.h>

#define USER_NAME "100.000USDorLoser"
#define PASS_WORD "huylong1999"
#define FIRE_BASE_HOST "vietlongpro1999-default-rtdb.firebaseio.com"
#define FIRE_BASE_AUTH ""
#define LCD_ADDRESS 0x27
#define LCD_SIZE 1602

extern LiquidCrystal_I2C lcd; // Khai báo LCD trong này để tiện in luôn trong hàm thư viện này, chỉ Lcd_Init rồi dùng lcd ở main là được

void Lcd_Init();
void Set_Up_Wifi();									// Khởi tạo Wifi
void Get_Data_Fire_Base();							// Lấy dữ liệu và điều chỉnh RELAY ở chân D0
void Display_And_Control(uint8_t Signal);           // Điều chỉnh van bơm và hiển thị trạng thái hiện tại 
void Connect_To_Firebase();							// Kết nối đến firebase
void Push_Data_Fire_Base(uint8_t hours, uint8_t minutes, uint8_t seconds, float Water_Flow);							// Đẩy dữ liệu lên Firebase

#endif