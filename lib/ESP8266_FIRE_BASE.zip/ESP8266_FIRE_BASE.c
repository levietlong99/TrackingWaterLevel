#include "ESP8266_FIRE_BASE.h"

LiquidCrystal_I2C lcd(LCD_ADDRESS, LCD_SIZE / 100, LCD_SIZE % 100);

uint8_t value1;
uint8_t value2;
uint8_t value3;
uint8_t value4;
unsigned int value;
uint8_t pump;
uint8_t faucet;
float water_level = 0;

char link_level[50];
char link_time[50];
char time_buff[50];

void Set_Up_Wifi_EEPROM(){

    EEPROM.begin(512);
    delay(10);
    read_EEPROM();
    if(value != 0){
  		Display_And_Control();
  	}
  	pinMode(D0, INPUT);
  	WiFi.begin(USER_NAME, PASS_WORD);
  	while(WiFi.status() != WL_CONNECTED){

    	delay(100);
  	}
}

void read_EEPROM(){

  for(int run = 0; run < 19; run++){

    time_buff[run] = EEPROM.read(run + 6);
  }
  value1 = EEPROM.read(0x00);
  value2 = EEPROM.read(0x01);
  value3 = EEPROM.read(0x02);
  value4 = EEPROM.read(0x03);
  value = (value1 << 24) | (value2 << 16) | (value3 << 8) | value4;

  pump = EEPROM.read(0x04);
  faucet = EEPROM.read(0x05);
  water_level = EEPROM.read(0x50);
}

void Lcd_Init(){

  lcd.begin();
}

void Display_And_Control(){

    if(faucet == 1){                  // 1 - Bật relay máy bơm, tín hiệu HIGH đi vào RELAY

    digitalWrite(D6, HIGH);
    lcd.setCursor(0, 0); lcd.print("FAUCET:  ON ");
    }
    else{                     // 2 - Tắt relay máy bơm, tín hiệu LOW đi vào RELAY

    digitalWrite(D6, LOW);
    lcd.setCursor(0, 0); lcd.print("FAUCET:  OFF");
    }
    if(pump == 1){                  // 1 - Bật relay máy bơm, tín hiệu HIGH đi vào RELAY

    digitalWrite(D7, HIGH);
    lcd.setCursor(0, 1); lcd.print("PUMP:    ON ");
    }
    else{                     // 2 - Tắt relay máy bơm, tín hiệu LOW đi vào RELAY

    digitalWrite(D7, LOW);
    lcd.setCursor(0, 1); lcd.print("PUMP:    OFF");
    }
    lcd.setCursor(0, 2);                // Hiển thị mực nước và ngày giờ
    lcd.print("WATER LEVEL  ");
    lcd.print(water_level);
    lcd.setCursor(0, 3);
    lcd.print(time_buff);
}

void Connect_To_Firebase(){
  
    Firebase.begin(FIRE_BASE_HOST, FIRE_BASE_AUTH);
    delay(100);
}
void Get_Data_Fire_Base(){

  String path = "/controller/";
  FirebaseObject object = Firebase.get(path);
  faucet = object.getInt("faucet");
  pump = object.getInt("pump");
}

void write_EEPROM(){                      // Ghi dữ liệu vừa nhận vào EEPROM

  for(int run = 0; run < 20; run++){

    EEPROM.write(run + 6, *(time_buff + run));    // Lưu Time buffer và Ngày giờ nếu bị watchdog reset
  }
  EEPROM.write(0x00, (value >> 24) & 0xFF);
  EEPROM.write(0x01, (value >> 16) & 0xFF);
  EEPROM.write(0x02, (value >> 8) & 0xFF);
  EEPROM.write(0x03, (value) & 0xFF);
  EEPROM.write(0x04, pump);
  EEPROM.write(0x05, faucet);
  EEPROM.write(0x50, water_level);
  EEPROM.commit();
}
void Push_Data_Fire_Base(uint8_t hours, uint8_t minutes, uint8_t seconds, float water_level1,\
      uint8_t days, uint8_t months, uint16_t years){ // Gửi dữ liệu bao gồm mực nước và thời điểm (ở dạng HHMMSS)mực nước lên Firebase

	water_level = water_level1;
	value++;
	if(value == 4294967295 - 1){               // Xóa EEPROM nếu tràn bộ nhớ

	    EEPROM.write(0x00, 0x00);
	    EEPROM.write(0x01, 0x00);
	    EEPROM.write(0x02, 0x00);
	  	EEPROM.write(0x03, 0x00);
	}
  	if(value % 15 == 0){                  // Tracking được 15s sẽ gửi 1 lần phục vụ vẽ biểu đồ

    	sprintf(link_level, "tracking/row_%d/level", value / 15);
    	Firebase.setInt(link_level, water_level);
    	sprintf(link_time, "tracking/row_%d/time", value / 15);
    	Firebase.setString(link_time, time_buff);
  	}
  	write_EEPROM();

    sprintf(time_buff, "%02d/%02d/%4d;%02d:%02d:%02d", days, months, years, hours, minutes, seconds); // Up dữ liệu liên tục
    Firebase.setInt("current/level", water_level);
  	Firebase.setString("current/last_updated", time_buff);
  	Display_And_Control();
}